Create database barbearia;
USE barbearia;

CREATE TABLE cliente (
 id_cliente SERIAL PRIMARY KEY,
    nome VARCHAR(100) NOT NULL,
    telefone VARCHAR(20),
    data_nascimento DATE,
    data_cadastro TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE barbeiros (
    id_barbeiro SERIAL PRIMARY KEY,
    nome VARCHAR(100) NOT NULL,
    telefone VARCHAR(20),
    ativo BOOLEAN DEFAULT TRUE
);

CREATE TABLE servicos (
    id_servico SERIAL PRIMARY KEY,
    nome VARCHAR(100) NOT NULL,
    descricao VARCHAR(255),
    preco DECIMAL(10,2) NOT NULL,
    duracao_minutos INTEGER NOT NULL,
    ativo BOOLEAN DEFAULT TRUE
);

INSERT INTO servicos
(nome, descricao, preco, duracao_minutos)
VALUES
('Corte Masculino', 'Corte tradicional ou moderno', 40.00, 30),
('Barba', 'Modelagem e acabamento da barba', 30.00, 20),
('Corte + Barba', 'Corte completo e barba', 65.00, 50),
('Sobrancelha', 'Acabamento da sobrancelha', 15.00, 10);

CREATE TABLE agendamentos (
    id_agendamento SERIAL PRIMARY KEY,

    id_cliente INTEGER NOT NULL,
    id_barbeiro INTEGER NOT NULL,

    data_hora TIMESTAMP NOT NULL,

    status VARCHAR(20) DEFAULT 'AGENDADO',

    observacao TEXT,

    data_criacao TIMESTAMP DEFAULT CURRENT_TIMESTAMP,

    FOREIGN KEY (id_cliente)
        REFERENCES clientes(id_cliente),

    FOREIGN KEY (id_barbeiro)
        REFERENCES barbeiros(id_barbeiro)
);

CREATE TABLE agendamento_servicos (
    id SERIAL PRIMARY KEY,

    id_agendamento INTEGER NOT NULL,
    id_servico INTEGER NOT NULL,

    preco DECIMAL(10,2) NOT NULL,

    FOREIGN KEY (id_agendamento)
        REFERENCES agendamentos(id_agendamento),

    FOREIGN KEY (id_servico)
        REFERENCES servicos(id_servico)
);

CREATE TABLE pagamentos (
    id_pagamento SERIAL PRIMARY KEY,

    id_agendamento INTEGER NOT NULL,

    valor DECIMAL(10,2) NOT NULL,

    forma_pagamento VARCHAR(30),

    status VARCHAR(20) DEFAULT 'PENDENTE',

    data_pagamento TIMESTAMP,

    FOREIGN KEY (id_agendamento)
        REFERENCES agendamentos(id_agendamento)
        );