/* ============================================
BARBERSYSTEM
============================================ */

/* ============================================
RECUPERAR DADOS
============================================ */

let clientes =
JSON.parse(localStorage.getItem("clientes")) || [];

let agendamentos =
JSON.parse(localStorage.getItem("agendamentos")) || [];

/* ============================================
ELEMENTOS HTML
============================================ */

const formCliente =
document.getElementById("formCliente");

const nomeCliente =
document.getElementById("nomeCliente");

const telefoneCliente =
document.getElementById("telefoneCliente");

const listaClientes =
document.getElementById("listaClientes");

const clienteAgendamento =
document.getElementById("clienteAgendamento");

const formAgendamento =
document.getElementById("formAgendamento");

const servico =
document.getElementById("servico");

const data =
document.getElementById("data");

const hora =
document.getElementById("hora");

const listaAgendamentos =
document.getElementById("listaAgendamentos");

const mensagemCliente =
document.getElementById("mensagemCliente");

const mensagemAgendamento =
document.getElementById("mensagemAgendamento");

/* ============================================
MÁSCARA DE TELEFONE
Formato: (11) 98765-4321
============================================ */

telefoneCliente.addEventListener(
"input",
function () {

    let valor =
        telefoneCliente.value.replace(/\D/g, "");

    valor =
        valor.substring(0, 11);


    if (valor.length <= 2) {

        valor =
            valor.replace(
                /^(\d{0,2})/,
                "($1"
            );

    }

    else if (valor.length <= 7) {

        valor =
            valor.replace(
                /^(\d{2})(\d{0,5})/,
                "($1) $2"
            );

    }

    else {

        valor =
            valor.replace(
                /^(\d{2})(\d{5})(\d{0,4})/,
                "($1) $2-$3"
            );

    }


    telefoneCliente.value = valor;

}


);

/* ============================================
SALVAR DADOS
============================================ */

function salvarDados() {

localStorage.setItem(
    "clientes",
    JSON.stringify(clientes)
);

localStorage.setItem(
    "agendamentos",
    JSON.stringify(agendamentos)
);


}

/* ============================================
MENSAGENS
============================================ */

function mostrarMensagem(
elemento,
texto,
tipo
) {

elemento.innerHTML =
    `<div class="${tipo}">${texto}</div>`;


setTimeout(
    function () {

        elemento.innerHTML = "";

    },
    3000
);


}

/* ============================================
CADASTRO DE CLIENTE
============================================ */

formCliente.addEventListener(
"submit",
function (event) {

    event.preventDefault();


    const nome =
        nomeCliente.value.trim();

    const telefone =
        telefoneCliente.value.trim();


    if (
        nome === "" ||
        telefone === ""
    ) {

        mostrarMensagem(
            mensagemCliente,
            "Preencha todos os campos.",
            "erro"
        );

        return;
    }


    /* Verifica se o telefone está completo */

    const telefoneNumeros =
        telefone.replace(/\D/g, "");


    if (telefoneNumeros.length !== 11) {

        mostrarMensagem(
            mensagemCliente,
            "Digite um telefone válido com DDD.",
            "erro"
        );

        return;
    }


    /* Verifica telefone duplicado */

    const clienteExistente =
        clientes.find(
            function (cliente) {

                return cliente.telefone === telefone;

            }
        );


    if (clienteExistente) {

        mostrarMensagem(
            mensagemCliente,
            "Já existe um cliente com esse telefone.",
            "erro"
        );

        return;
    }


    /* Cria novo cliente */

    const novoCliente = {

        id: Date.now(),

        nome: nome,

        telefone: telefone

    };


    clientes.push(novoCliente);


    salvarDados();

    atualizarSistema();


    mostrarMensagem(
        mensagemCliente,
        "Cliente cadastrado com sucesso!",
        "sucesso"
    );


    formCliente.reset();

}


);

/* ============================================
EXCLUIR CLIENTE
============================================ */

function excluirCliente(id) {

const possuiAgendamento =
    agendamentos.some(
        function (agendamento) {

            return agendamento.clienteId === id;

        }
    );


if (possuiAgendamento) {

    alert(
        "Não é possível excluir este cliente, pois ele possui agendamentos."
    );

    return;
}


const confirmar =
    confirm(
        "Deseja realmente excluir este cliente?"
    );


if (!confirmar) {
    return;
}


clientes =
    clientes.filter(
        function (cliente) {

            return cliente.id !== id;

        }
    );


salvarDados();

atualizarSistema();


}

/* ============================================
AGENDAMENTO
============================================ */

formAgendamento.addEventListener(
"submit",
function (event) {

    event.preventDefault();


    const clienteId =
        Number(clienteAgendamento.value);

    const servicoSelecionado =
        servico.value;

    const dataSelecionada =
        data.value;

    const horaSelecionada =
        hora.value;


    /* Validação */

    if (
        !clienteId ||
        servicoSelecionado === "" ||
        dataSelecionada === "" ||
        horaSelecionada === ""
    ) {

        mostrarMensagem(
            mensagemAgendamento,
            "Preencha todos os campos do agendamento.",
            "erro"
        );

        return;
    }


    /* ====================================
       NÃO PERMITE DATA PASSADA
       ==================================== */

    const hoje =
        new Date();

    hoje.setHours(
        0,
        0,
        0,
        0
    );


    const dataInformada =
        new Date(
            dataSelecionada + "T00:00:00"
        );


    if (dataInformada < hoje) {

        mostrarMensagem(
            mensagemAgendamento,
            "Não é possível realizar um agendamento em uma data passada.",
            "erro"
        );

        return;
    }


    /* ====================================
       HORÁRIO OCUPADO
       ==================================== */

    const horarioOcupado =
        agendamentos.some(
            function (agendamento) {

                return (
                    agendamento.data === dataSelecionada &&
                    agendamento.hora === horaSelecionada &&
                    agendamento.status !== "Cancelado"
                );

            }
        );


    if (horarioOcupado) {

        mostrarMensagem(
            mensagemAgendamento,
            "Este horário já está ocupado.",
            "erro"
        );

        return;
    }


    /* Cria novo agendamento */

    const novoAgendamento = {

        id: Date.now(),

        clienteId: clienteId,

        servico: servicoSelecionado,

        data: dataSelecionada,

        hora: horaSelecionada,

        status: "Agendado"

    };


    agendamentos.push(
        novoAgendamento
    );


    salvarDados();

    atualizarSistema();


    mostrarMensagem(
        mensagemAgendamento,
        "Agendamento realizado com sucesso!",
        "sucesso"
    );


    formAgendamento.reset();

}


);

/* ============================================
ALTERAR STATUS
============================================ */

function alterarStatus(
id,
novoStatus
) {

const agendamento =
    agendamentos.find(
        function (item) {

            return item.id === id;

        }
    );


if (!agendamento) {

    alert(
        "Agendamento não encontrado."
    );

    return;
}


agendamento.status =
    novoStatus;


salvarDados();

atualizarSistema();


}

/* ============================================
EXCLUIR AGENDAMENTO
============================================ */

function excluirAgendamento(id) {

const confirmar =
    confirm(
        "Deseja excluir este agendamento?"
    );


if (!confirmar) {
    return;
}


agendamentos =
    agendamentos.filter(
        function (agendamento) {

            return agendamento.id !== id;

        }
    );


salvarDados();

atualizarSistema();


}

/* ============================================
MOSTRAR CLIENTES
============================================ */

function renderizarClientes() {

listaClientes.innerHTML = "";


clienteAgendamento.innerHTML =
    `
    <option value="">
        Selecione um cliente
    </option>
    `;


clientes.forEach(
    function (cliente) {

        const linha =
            document.createElement("tr");


        linha.innerHTML =
            `
            <td>
                ${cliente.nome}
            </td>

            <td>
                ${cliente.telefone}
            </td>

            <td>

                <button
                    class="btn-excluir"
                    onclick="excluirCliente(${cliente.id})"
                >
                    Excluir
                </button>

            </td>
            `;


        listaClientes.appendChild(
            linha
        );


        const option =
            document.createElement(
                "option"
            );


        option.value =
            cliente.id;

        option.textContent =
            cliente.nome;


        clienteAgendamento.appendChild(
            option
        );

    }
);


if (clientes.length === 0) {

    listaClientes.innerHTML =
        `
        <tr>
            <td colspan="3">
                Nenhum cliente cadastrado.
            </td>
        </tr>
        `;

}


}

/* ============================================
MOSTRAR AGENDAMENTOS
============================================ */

function renderizarAgendamentos() {

listaAgendamentos.innerHTML = "";


agendamentos.forEach(
    function (agendamento) {

        const cliente =
            clientes.find(
                function (item) {

                    return (
                        item.id ===
                        agendamento.clienteId
                    );

                }
            );


        const nome =
            cliente
                ? cliente.nome
                : "Cliente não encontrado";


        const linha =
            document.createElement("tr");


        let classeStatus =
            "status-agendado";


        if (
            agendamento.status ===
            "Concluído"
        ) {

            classeStatus =
                "status-concluido";

        }


        if (
            agendamento.status ===
            "Cancelado"
        ) {

            classeStatus =
                "status-cancelado";

        }


        linha.innerHTML =
            `
            <td>
                ${nome}
            </td>

            <td>
                ${agendamento.servico}
            </td>

            <td>
                ${formatarData(
                    agendamento.data
                )}
            </td>

            <td>
                ${agendamento.hora}
            </td>

            <td class="${classeStatus}">
                ${agendamento.status}
            </td>

            <td>

                <div class="acoes">

                    <button
                        class="btn-concluir"
                        onclick="alterarStatus(
                            ${agendamento.id},
                            'Concluído'
                        )"
                    >
                        Concluir
                    </button>


                    <button
                        class="btn-cancelar"
                        onclick="alterarStatus(
                            ${agendamento.id},
                            'Cancelado'
                        )"
                    >
                        Cancelar
                    </button>


                    <button
                        class="btn-excluir"
                        onclick="excluirAgendamento(
                            ${agendamento.id}
                        )"
                    >
                        Excluir
                    </button>

                </div>

            </td>
            `;


        listaAgendamentos.appendChild(
            linha
        );

    }
);


if (agendamentos.length === 0) {

    listaAgendamentos.innerHTML =
        `
        <tr>

            <td colspan="6">
                Nenhum agendamento cadastrado.
            </td>

        </tr>
        `;

}


}

/* ============================================
FORMATAR DATA
============================================ */

function formatarData(data) {

if (!data) {
    return "";
}


const partes =
    data.split("-");


if (partes.length !== 3) {
    return data;
}


return (
    partes[2] +
    "/" +
    partes[1] +
    "/" +
    partes[0]
);


}

/* ============================================
DASHBOARD
============================================ */

function atualizarDashboard() {

const totalClientes =
    clientes.length;


const totalAgendamentos =
    agendamentos.filter(
        function (agendamento) {

            return (
                agendamento.status ===
                "Agendado"
            );

        }
    ).length;


const totalConcluidos =
    agendamentos.filter(
        function (agendamento) {

            return (
                agendamento.status ===
                "Concluído"
            );

        }
    ).length;


document.getElementById(
    "totalClientes"
).textContent =
    totalClientes;


document.getElementById(
    "totalAgendamentos"
).textContent =
    totalAgendamentos;


document.getElementById(
    "totalConcluidos"
).textContent =
    totalConcluidos;


}

/* ============================================
ATUALIZAR SISTEMA
============================================ */

function atualizarSistema() {

renderizarClientes();

renderizarAgendamentos();

atualizarDashboard();


}

/* ============================================
INICIALIZAÇÃO
============================================ */

atualizarSistema();